from django.shortcuts import render
from datetime import datetime
from .models import product 


# Create your views here.
def products(request):
    context = {
       'products': product.objects.all()


    }
    return render(request , 'products/products.html', context)


def product(request):
    return render(request , 'products/product.html')



def search(request):
    return render(request , 'products/search.html')

