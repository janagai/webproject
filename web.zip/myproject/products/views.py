from django.shortcuts import get_object_or_404 , render
from datetime import datetime
from .models import product 


# Create your views here.
def products(request):
    name=None
    if 'searchname' in request.GET:

     name=request.GET['searchname']
    context = {
       'productsq': product.objects.all(),
        'name':name

    }
    return render(request , 'products/products.html', context)


def product1(request , p_id):

    context={
      'p':get_object_or_404(product, pk=p_id)
    }
    return render(request , 'products/product.html',context)


def search(request ):

    return render(request , 'products/search.html')


