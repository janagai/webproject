from django.shortcuts import get_object_or_404 , render
from datetime import datetime
from .models import product 


# Create your views here.
def products(request):
    pro= product.objects.all()

    name = None
    if 'searchname' in request.GET:
        name= request.GET['searchname']
        if name:
            pro= pro.filter(name__icontains=name)
    context = {
       'productsq': pro


    }
    return render(request , 'products/products.html',context)

def product1(request , p_id):

    context={
      'p':get_object_or_404(product, pk=p_id)
    }
    return render(request , 'products/product.html',context)


def search(request ):

    return render(request , 'products/search.html')


