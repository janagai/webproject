from django.urls import path
from . import views

urlpatterns = [
    
   path('',views.products,name='products'),
   path('<int:p_id>', views.product1,name='product'),
   path('search', views.product1,name='search'),
   
 
]
