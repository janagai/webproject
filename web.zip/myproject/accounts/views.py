from django.shortcuts import render , redirect
from django.contrib import messages
from django.contrib.auth.models import User
from .models import UserProfile
import re

# Create your views here.

def signin(request):
   
    return render(request , 'accounts/signin.html')
  

def signup(request):
    if request.method =='POST' and 'btnup' in request.POST:
       fname=None
       lname=None
       address=None
       city=None
       state=None
       zip=None
       email=None
       username=None
       password=None
       terms=None

       if 'fname' in request.POST: fname=request.POST['fname']
       else: messages.error(request,'error in first name')

       if 'lname' in request.POST: lname=request.POST['lname']
       else: messages.error(request,'error in last name')

       if 'add' in request.POST: address=request.POST['add']
       else: messages.error(request,'error in address ')

       if 'city' in request.POST: city=request.POST['city']
       else: messages.error(request,'error in city ')

       if 'state' in request.POST: state=request.POST['state']
       else: messages.error(request,'error in state ')

       if 'zip' in request.POST: zip=request.POST['zip']
       else: messages.error(request,'error in zip ')

       if 'email' in request.POST: email=request.POST['email']
       else: messages.error(request,'error in email ')

       if 'user' in request.POST: username=request.POST['user']
       else: messages.error(request,'error in username ')

       if 'pass' in request.POST: password=request.POST['pass']
       else: messages.error(request,'error in password ')

       if 'terms' in request.POST: terms=request.POST['terms']
       if fname and lname and address and city and state and zip and email and username and password:
           if terms=='on':
            if User.objects.filter(username=username).exists():
             messages.error(request,'the user name is taken')
            else:
                if User.objects.filter(email=email).exists():
                  messages.error(request,'the email is taken')
                else:
                  patt="^\w([+-.']\w+)*@\w+([-.]w+)*\.\w+([-.]\w+)*$"
                  if re.match(patt,email):
                     
                     user=User.objects.create_user(first_name=fname,last_name=lname, email=email , username=username , password=password )
                     user.save()

                     userprofile=UserProfile(user = user,address=address,city=city,state=state, zip = zip_num)
                     userprofile.save()
                     messages.success(request,'your account is create')
                 
                  else:
                     messages.error(request,'invalid email')
           else:
               messages.error(request,'you must agree to the terms')
       else:
           messages.error(request,'empty field')

       return redirect('signup')
    else:
        return render(request,'accounts/signup.html')
    return render(request , 'accounts/signup.html')



def profile(request):
    return render(request , 'accounts/profile.html')