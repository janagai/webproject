from django.shortcuts import render
from django.http import HttpResponse
from products.models import product
# Create your views here.

def index(request):
     context = {
       'productsq': product.objects.all()
    }
     return render(request , 'pages\page1.html',context)

